package com.example.inventorio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.inventorio.data.AppDatabase;
import com.example.inventorio.data.InventoryItem;
import com.example.inventorio.data.InventoryItemDao;
import com.example.inventorio.ui.EditItemDialogFragment;
import com.example.inventorio.ui.InventoryAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InventoryListActivity extends AppCompatActivity
    implements AddItemBottomSheetDialogFragment.AddItemListener,
               InventoryAdapter.OnItemInteractionListener,
               EditItemDialogFragment.EditItemListener,
               NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = "InventoryListActivity";
    private static final String PREFS_NAME = "InventorioPrefs"; // Matching SettingsActivity
    private static final String PREF_SMS_ENABLED = "sms_notifications_enabled"; // Matching SettingsActivity
    private static final String SMS_TARGET_PHONE_NUMBER = "1234567890"; // For emulator testing

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private NavigationView navigationView;
    private FloatingActionButton fabAddItem;
    private RecyclerView recyclerViewInventory;
    private InventoryAdapter inventoryAdapter;
    private InventoryItemDao inventoryItemDao;
    private ExecutorService executorService;
    private Toolbar toolbar;
    private ConstraintLayout emptyStateLayout;
    private ImageView emptyStateImageView;
    private TextView emptyStateTextView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_list);

        toolbar = findViewById(R.id.toolbarInventory);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        fabAddItem = findViewById(R.id.fabAddItem);
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        emptyStateImageView = findViewById(R.id.emptyStateImageView);
        emptyStateTextView = findViewById(R.id.emptyStateTextView);

        AppDatabase db = AppDatabase.getDatabase(getApplicationContext());
        inventoryItemDao = db.inventoryItemDao();
        executorService = Executors.newSingleThreadExecutor();
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        setupRecyclerView();
        setupOnBackPressed();

        fabAddItem.setOnClickListener(view -> {
            AddItemBottomSheetDialogFragment addItemSheet = AddItemBottomSheetDialogFragment.newInstance();
            addItemSheet.setAddItemListener(this);
            addItemSheet.show(getSupportFragmentManager(), AddItemBottomSheetDialogFragment.TAG);
        });

        loadInventoryItems();
    }

    private void setupRecyclerView() {
        inventoryAdapter = new InventoryAdapter(this);
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewInventory.setAdapter(inventoryAdapter);
    }

     private void setupOnBackPressed() {
        OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
            @Override
            public void handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else {
                    setEnabled(false);
                    InventoryListActivity.super.getOnBackPressedDispatcher().onBackPressed();
                    setEnabled(true);
                }
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void loadInventoryItems() {
        executorService.execute(() -> {
            List<InventoryItem> items = inventoryItemDao.getAllItems();
            runOnUiThread(() -> {
                inventoryAdapter.setItems(items);
                if (items.isEmpty()) {
                    recyclerViewInventory.setVisibility(View.GONE);
                    emptyStateLayout.setVisibility(View.VISIBLE);
                } else {
                    recyclerViewInventory.setVisibility(View.VISIBLE);
                    emptyStateLayout.setVisibility(View.GONE);
                }
            });
        });
    }

    @Override
    public void onItemAdded(String name, String category, int quantity) {
        InventoryItem newItem = new InventoryItem(name, category, quantity);
        executorService.execute(() -> {
            inventoryItemDao.insert(newItem);
            loadInventoryItems(); // Reload items to reflect the new addition
            runOnUiThread(() -> {
                Toast.makeText(InventoryListActivity.this, "Item added: " + name, Toast.LENGTH_SHORT).show();
                checkAndSendLowStockSms(newItem);
            });
        });
    }

    @Override
    public void onEditItem(InventoryItem item) {
        EditItemDialogFragment dialogFragment = EditItemDialogFragment.newInstance(item.id, item.quantity);
        dialogFragment.setEditItemListener(this); // Ensure listener is set
        dialogFragment.show(getSupportFragmentManager(), "EditItemDialog");
    }

    @Override
    public void onItemQuantityUpdated(long itemId, int newQuantity) {
        executorService.execute(() -> {
            InventoryItem item = inventoryItemDao.getItemById(itemId);
            if (item != null) {
                item.quantity = newQuantity;
                inventoryItemDao.update(item);
                loadInventoryItems(); // Reload items to reflect the update
                runOnUiThread(() -> {
                    Toast.makeText(InventoryListActivity.this, item.name + " updated", Toast.LENGTH_SHORT).show();
                    checkAndSendLowStockSms(item);
                });
            } else {
                 runOnUiThread(() ->
                    Toast.makeText(InventoryListActivity.this, "Error: Item not found", Toast.LENGTH_SHORT).show()
                );
            }
        });
    }

    @Override
    public void onDeleteItem(InventoryItem item) {
        new AlertDialog.Builder(this)
            .setTitle("Delete Item")
            .setMessage("Are you sure you want to delete " + item.name + "?")
            .setPositiveButton("Delete", (dialog, which) -> {
                executorService.execute(() -> {
                    inventoryItemDao.delete(item);
                    loadInventoryItems(); // Reload items
                    runOnUiThread(() ->
                        Toast.makeText(InventoryListActivity.this, item.name + " deleted", Toast.LENGTH_SHORT).show()
                    );
                });
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void checkAndSendLowStockSms(InventoryItem item) {
        boolean smsEnabled = sharedPreferences.getBoolean(PREF_SMS_ENABLED, false);
        if (smsEnabled && item.quantity <= 2) {
            String message = "Low stock alert! " + item.name + " quantity is " + item.quantity + ".";
            SettingsActivity.sendSms(this, SMS_TARGET_PHONE_NUMBER, message);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_inventory) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(InventoryListActivity.this, SettingsActivity.class);
            startActivity(intent);
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown();
        }
    }
}
