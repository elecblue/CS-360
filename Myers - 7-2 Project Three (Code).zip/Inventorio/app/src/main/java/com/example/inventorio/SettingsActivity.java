package com.example.inventorio;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.google.android.material.materialswitch.MaterialSwitch;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "InventorioPrefs";
    private static final String PREF_SMS_ENABLED = "sms_notifications_enabled";
    private static final String PREF_SMS_PERMISSION_REQUESTED_ONCE = "sms_permission_requested_once";
    private static final String TAG = "SettingsActivity";

    private MaterialSwitch switchSmsNotifications;
    private TextView textSmsNotificationsDescription;
    private LinearLayout layoutPermissionRationale;
    private Button buttonRequestSmsPermission;

    private SharedPreferences sharedPreferences;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permission is granted.
                    sharedPreferences.edit().putBoolean(PREF_SMS_ENABLED, true).apply();
                    switchSmsNotifications.setChecked(true);
                } else {
                    // Permission is denied.
                    sharedPreferences.edit().putBoolean(PREF_SMS_ENABLED, false).apply();
                    switchSmsNotifications.setChecked(false);
                }
                updateUiBasedOnPermission();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbarSettings);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        switchSmsNotifications = findViewById(R.id.switchSmsNotifications);
        textSmsNotificationsDescription = findViewById(R.id.textSmsNotificationsDescription);
        layoutPermissionRationale = findViewById(R.id.layoutPermissionRationale);
        buttonRequestSmsPermission = findViewById(R.id.buttonRequestSmsPermission);

        // Load saved preference for the switch
        boolean smsEnabled = sharedPreferences.getBoolean(PREF_SMS_ENABLED, false);
        switchSmsNotifications.setChecked(smsEnabled);

        switchSmsNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // User wants to enable SMS notifications
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    sharedPreferences.edit().putBoolean(PREF_SMS_ENABLED, true).apply();
                } else {
                    // Permission not granted, request it
                    sharedPreferences.edit().putBoolean(PREF_SMS_PERMISSION_REQUESTED_ONCE, true).apply();
                    requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                    // The switch state will be updated by the launcher's callback
                }
            } else {
                // User wants to disable SMS notifications
                sharedPreferences.edit().putBoolean(PREF_SMS_ENABLED, false).apply();
            }
            updateUiBasedOnPermission();
        });

        buttonRequestSmsPermission.setOnClickListener(v -> {
            sharedPreferences.edit().putBoolean(PREF_SMS_PERMISSION_REQUESTED_ONCE, true).apply();
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update UI based on current permission status and preference when activity resumes
        updateUiBasedOnPermission();
    }

    private void updateUiBasedOnPermission() {
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        boolean smsPrefEnabled = sharedPreferences.getBoolean(PREF_SMS_ENABLED, false);
        boolean permissionRequestedOnce = sharedPreferences.getBoolean(PREF_SMS_PERMISSION_REQUESTED_ONCE, false);

        if (permissionGranted) {
            switchSmsNotifications.setChecked(smsPrefEnabled); // Reflect user's actual choice if permission is there
            textSmsNotificationsDescription.setText(smsPrefEnabled ? R.string.sms_notifications_description_enabled : R.string.sms_notifications_description_disabled_but_permission_granted);
            layoutPermissionRationale.setVisibility(View.GONE);
            switchSmsNotifications.setEnabled(true);
        } else {
            // Permission not granted
            switchSmsNotifications.setChecked(false); // Can't be enabled without permission
            sharedPreferences.edit().putBoolean(PREF_SMS_ENABLED, false).apply(); // Ensure preference is also false

            if (permissionRequestedOnce && !shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
                // User has denied permission permanently (or it's restricted by policy)
                textSmsNotificationsDescription.setText(R.string.sms_notifications_description_permission_permanently_denied);
                layoutPermissionRationale.setVisibility(View.GONE); // No point showing rationale if permanently denied
                switchSmsNotifications.setEnabled(false); // Disable switch if permission permanently denied
            } else {
                 // Permission not granted, but can still be requested (or rationale can be shown)
                textSmsNotificationsDescription.setText(R.string.sms_notifications_description_disabled);
                layoutPermissionRationale.setVisibility(View.VISIBLE);
                switchSmsNotifications.setEnabled(true);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void sendSms(Context context, String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                // For messages longer than 160 characters, use divideMessage to get parts
                // For simplicity, this example sends a single part message.
                 // For the PendingIntent, null is used as we don't need a callback for sent/delivered status here.
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Log.d(TAG, "SMS sent to " + phoneNumber + ": " + message);
                Toast.makeText(context, "Low stock SMS sent!", Toast.LENGTH_SHORT).show(); // Optional: user feedback
            } catch (Exception e) {
                Log.e(TAG, "SMS sending failed", e);
                Toast.makeText(context, "SMS sending failed.", Toast.LENGTH_SHORT).show(); // Optional: user feedback
            }
        } else {
            Log.w(TAG, "SEND_SMS permission not granted. Cannot send SMS.");
            // Optionally, inform the user more directly here if appropriate for the context
        }
    }
}