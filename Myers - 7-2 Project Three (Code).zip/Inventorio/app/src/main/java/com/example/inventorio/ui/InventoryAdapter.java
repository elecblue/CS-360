package com.example.inventorio.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.inventorio.R;
import com.example.inventorio.data.InventoryItem;
import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private List<InventoryItem> items = new ArrayList<>();
    private OnItemInteractionListener listener;

    public interface OnItemInteractionListener {
        void onEditItem(InventoryItem item);
        void onDeleteItem(InventoryItem item);
    }

    public InventoryAdapter(OnItemInteractionListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem currentItem = items.get(position);
        holder.textViewItemName.setText(currentItem.name);
        holder.textViewItemCategory.setText("Category: " + currentItem.category);
        holder.textViewItemQuantity.setText("Quantity: " + currentItem.quantity);

        holder.buttonEditItem.setOnClickListener(v -> listener.onEditItem(currentItem));
        holder.buttonDeleteItem.setOnClickListener(v -> listener.onDeleteItem(currentItem));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void setItems(List<InventoryItem> items) {
        this.items = items;
        notifyDataSetChanged(); // For simplicity, ideally use DiffUtil
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView textViewItemName;
        TextView textViewItemCategory;
        TextView textViewItemQuantity;
        ImageButton buttonEditItem;
        ImageButton buttonDeleteItem;

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewItemName = itemView.findViewById(R.id.textViewItemName);
            textViewItemCategory = itemView.findViewById(R.id.textViewItemCategory);
            textViewItemQuantity = itemView.findViewById(R.id.textViewItemQuantity);
            buttonEditItem = itemView.findViewById(R.id.buttonEditItem);
            buttonDeleteItem = itemView.findViewById(R.id.buttonDeleteItem);
        }
    }
}
