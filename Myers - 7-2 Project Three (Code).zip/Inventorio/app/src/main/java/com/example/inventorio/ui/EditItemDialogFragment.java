package com.example.inventorio.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.inventorio.R;

public class EditItemDialogFragment extends DialogFragment {

    private static final String ARG_ITEM_ID = "item_id";
    private static final String ARG_CURRENT_QUANTITY = "current_quantity";

    private EditText editTextQuantity;
    private long itemId;
    private int currentQuantity;

    private EditItemListener listener;

    public interface EditItemListener {
        void onItemQuantityUpdated(long itemId, int newQuantity);
    }

    public static EditItemDialogFragment newInstance(long itemId, int currentQuantity) {
        EditItemDialogFragment fragment = new EditItemDialogFragment();
        Bundle args = new Bundle();
        args.putLong(ARG_ITEM_ID, itemId);
        args.putInt(ARG_CURRENT_QUANTITY, currentQuantity);
        fragment.setArguments(args);
        return fragment;
    }

    // Add this public setter method
    public void setEditItemListener(EditItemListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // You can keep this as a fallback or remove it if you always set the listener via the setter.
        // For now, let's keep it but ensure the explicit setter takes precedence if called.
        if (this.listener == null && context instanceof EditItemListener) {
            this.listener = (EditItemListener) context;
        } else if (this.listener == null) {
            // Optional: throw an exception if the listener isn't set via either method by the time it's needed.
            // However, the explicit call in InventoryListActivity should prevent this.
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        if (getArguments() != null) {
            itemId = getArguments().getLong(ARG_ITEM_ID);
            currentQuantity = getArguments().getInt(ARG_CURRENT_QUANTITY);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_edit_item, null);

        editTextQuantity = view.findViewById(R.id.editTextQuantity);
        Button buttonSave = view.findViewById(R.id.buttonSave);
        Button buttonCancel = view.findViewById(R.id.buttonCancel);

        editTextQuantity.setText(String.valueOf(currentQuantity));

        builder.setView(view);

        AlertDialog dialog = builder.create();

        buttonSave.setOnClickListener(v -> {
            if (listener == null) {
                // This case should ideally not happen if setEditItemListener is called correctly.
                Toast.makeText(getContext(), "Listener not set", Toast.LENGTH_SHORT).show();
                return;
            }
            String quantityStr = editTextQuantity.getText().toString();
            if (TextUtils.isEmpty(quantityStr)) {
                editTextQuantity.setError("Quantity cannot be empty");
                return;
            }
            try {
                int newQuantity = Integer.parseInt(quantityStr);
                if (newQuantity < 0) {
                    editTextQuantity.setError("Quantity cannot be negative");
                    return;
                }
                listener.onItemQuantityUpdated(itemId, newQuantity);
                dismiss();
            } catch (NumberFormatException e) {
                editTextQuantity.setError("Invalid number");
            }
        });

        buttonCancel.setOnClickListener(v -> dismiss());

        return dialog;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null; // Clean up the listener
    }
}
