package com.example.inventorio;
// This file is not part of the Project Two submission
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // activity_main.xml

        // Initialize your views
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        buttonSayHello.setEnabled(false); // Start with the button disabled

        // Add the TextChangedListener to nameText
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Might need later
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Check if the text field is empty or not
                // Trim the text to ensure spaces alone don't enable the button
                buttonSayHello.setEnabled(!s.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Might need later
            }
        });

         // Set up a button to trigger SayHello
        buttonSayHello.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 SayHello(v); // Pass the clicked view (the button itself)
             }
         });
    }

    public void SayHello(View view) {
        // Check that the contents of nameText are not null or empty
        String name = nameText.getText().toString().trim();
        if (!name.isEmpty()) {
            // Display a message
            String message = "Hello, " + name + "!";
            textGreeting.setText(message);
        } else {
            // Optionally, handle the case where nameText is empty
            textGreeting.setText("Please enter a name.");
        }
    }
}
