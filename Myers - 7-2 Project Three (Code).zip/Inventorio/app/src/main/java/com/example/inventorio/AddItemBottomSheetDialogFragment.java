package com.example.inventorio;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class AddItemBottomSheetDialogFragment extends BottomSheetDialogFragment {

    public static final String TAG = "AddItemBottomSheet";

    private TextInputLayout itemNameInputLayout, itemCategoryInputLayout, itemQuantityInputLayout;
    private TextInputEditText editTextItemName, editTextItemCategory, editTextItemQuantity;
    private Button buttonSaveItem;

    // Interface for callback to the activity
    public interface AddItemListener {
        void onItemAdded(String name, String category, int quantity);
    }
    private AddItemListener addItemListener;


    public static AddItemBottomSheetDialogFragment newInstance() {
        return new AddItemBottomSheetDialogFragment();
    }

    // Set the listener from the Activity
    public void setAddItemListener(AddItemListener listener) {
        this.addItemListener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bottom_sheet_add_item, container, false);

        itemNameInputLayout = view.findViewById(R.id.itemNameInputLayout);
        editTextItemName = view.findViewById(R.id.editTextItemName);
        itemCategoryInputLayout = view.findViewById(R.id.itemCategoryInputLayout);
        editTextItemCategory = view.findViewById(R.id.editTextItemCategory);
        itemQuantityInputLayout = view.findViewById(R.id.itemQuantityInputLayout);
        editTextItemQuantity = view.findViewById(R.id.editTextItemQuantity);
        buttonSaveItem = view.findViewById(R.id.buttonSaveItem);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        buttonSaveItem.setOnClickListener(v -> {
            String name = editTextItemName.getText() != null ? editTextItemName.getText().toString().trim() : "";
            String category = editTextItemCategory.getText() != null ? editTextItemCategory.getText().toString().trim() : "";
            String quantityStr = editTextItemQuantity.getText() != null ? editTextItemQuantity.getText().toString().trim() : "";

            boolean isValid = true;
            if (name.isEmpty()) {
                itemNameInputLayout.setError(getString(R.string.error_field_required));
                isValid = false;
            } else {
                itemNameInputLayout.setError(null);
            }

            // Add more validation for category later
            if (category.isEmpty()) { // Making category optional
                // itemCategoryInputLayout.setError(getString(R.string.error_field_required));
                // isValid = false;
            } else {
                itemCategoryInputLayout.setError(null);
            }


            int quantity = 0;
            if (quantityStr.isEmpty()) {
                itemQuantityInputLayout.setError(getString(R.string.error_field_required));
                isValid = false;
            } else {
                try {
                    quantity = Integer.parseInt(quantityStr);
                    if (quantity < 0) {
                        itemQuantityInputLayout.setError(getString(R.string.error_quantity_non_negative));
                        isValid = false;
                    } else {
                        itemQuantityInputLayout.setError(null);
                    }
                } catch (NumberFormatException e) {
                    itemQuantityInputLayout.setError(getString(R.string.error_invalid_number));
                    isValid = false;
                }
            }

            if (isValid) {
                // Replace with database code later
                String message = "Item Added: " + name + ", Category: " + category + ", Qty: " + quantity;
                Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();

                if (addItemListener != null) {
                    addItemListener.onItemAdded(name, category, quantity);
                }

                dismiss(); // Close the bottom sheet
            }
        });
    }
}


