package com.example.inventorio.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "users", indices = {@Index(value = {"username"}, unique = true)})
public class User {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String username;
    public String password; // In a real app, always hash passwords!

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}